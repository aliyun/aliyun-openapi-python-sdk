======================
aliyun-python-sdk-core
======================


This is the core module of Aliyun Python SDK.

Aliyun Python SDK is the official software development kit. It makes things easy to integrate your Python application,
library, or script with Aliyun services.

This module works on Python versions:

   * 3.0.0 and greater


Documentation:

Please visit http://develop.aliyun.com/sdk/python